module.exports = {
  oauth: "https://accounts.google.com/o/oauth2/v2/auth",
  token: "https://oauth2.googleapis.com/token",
  gmail_messages: "https://www.googleapis.com/gmail/v1/users/me/messages",
};
