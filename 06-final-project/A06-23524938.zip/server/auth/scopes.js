module.exports = {
  read: "https://www.googleapis.com/auth/gmail.readonly",
};
