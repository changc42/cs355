# Email Rater

Find out how positive or negative your emails are

To view project, clone repo, cd into /server directory, run `npm i`, run `node index.js`, and go to http://localhost:3000

**IMPORTANT**: server/auth/keys.js file not pushed to github. must obtain auth keys through other means

Created using only the core libraries of node JS. (No expressJS, no passportJS, no API libraries(bare http/rest))
