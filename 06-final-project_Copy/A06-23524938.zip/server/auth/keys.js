module.exports = {
  client_id:
    "943658562563-o6dn04a345on40qfsgu30gkc497ics35.apps.googleusercontent.com",
  client_secret: "ALWmHyKEZFI4AapUVMUXmi15",
  API_KEY: "AIzaSyBUguplc_rYJANc_ep1rKF3TxJugbqS44c",
  state: "dsjhgio3io oIOHF8f93h (f FFSKLhf[_", //used to assure that redirects come from google servers
};
