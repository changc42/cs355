/*
=======================
05 - Morse Decoder - MorseEmitter.js
=======================
Student ID:
Comment (Required):

=======================
*/
const EventEmitter = require('events');
const morse = require("../data/morse-code.json");

class MorseEmitter extends EventEmitter {
	
	
	
	
}

module.exports = MorseEmitter;
