/*
=======================
05 - Morse Decoder - index.js
=======================
Student ID:
Comment (Required):

=======================
*/
const MorseEmitter = require("./modules/MorseEmitterEncrypted");
const morse = require("./data/morse-code.json");
let morse_emitter = new MorseEmitter();
















morse_emitter.start();